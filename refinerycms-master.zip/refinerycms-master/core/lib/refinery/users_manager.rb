require 'zilch/authorisation/users_manager'

module Refinery
  module Core
    class UsersManager < Zilch::Authorisation::UsersManager
    end
  end
end
