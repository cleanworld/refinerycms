module Refinery
  module InvalidEngine
    class Engine < Rails::Engine
    end
  end
end
