require 'spec_helper_no_rails'
require 'refinery/users_manager'

module Refinery
  module Core
    RSpec.describe UsersManager do
    end
  end
end
