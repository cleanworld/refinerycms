require 'refinery/images'
