shared_context "no existing images" do
 let(:image) { FactoryGirl.create(:image) }
end
