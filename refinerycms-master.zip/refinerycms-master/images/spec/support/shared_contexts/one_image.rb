shared_context "one image" do
 let!(:image) { FactoryGirl.create(:image) }
end
