shared_examples 'edits an image' do
  pending
end