module Refinery
  module Testing
    module FeatureMacros
      autoload :Authentication, 'refinery/testing/feature_macros/authentication'
    end
  end
end
