FactoryGirl.define do
  factory :page_part, class: Refinery::PagePart do
    title 'Body'
    slug 'side_body'
  end
end
