module Refinery
  class PagePresenter < BasePresenter

    def menu_title_type
      @model.menu_title_type
    end

  end
end
