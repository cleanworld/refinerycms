Spring.application_root = File.expand_path('../../spec/dummy', __FILE__) if defined?(Spring)
